import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data= {'x': [1.27,2.25,2.5,3.6],
        'y': [2.3,2.95,3.5,5.1]}
data=pd.DataFrame.from_dict(data)
X = data.iloc[:, 0]
Y = data.iloc[:, 1]
x= 0
y=4.5
xi=0
for i in range(len(X)):
    xi= data.x[i]
    for j in range(len(Y)):
        if i!=j:
            xi=xi*(y-data.y[j])/((data.y[i])-(data.y[j]))
    x=x+xi
# print(round(x,4))
# plt.scatter(X,Y)
# plt.show()
# plt.scatter(X, Y) # actual
plt.plot([data.x, data.y], color='red') # predicted
plt.show()

