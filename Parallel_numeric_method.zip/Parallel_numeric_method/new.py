import matplotlib.pyplot as plt
guess =0.1
cube = 27
increment =0.1
epsilon =0.1
g =[guess]
while (abs(guess**3 - cube) >= epsilon):
    guess+=increment
    g.append(guess)
if abs(guess**3 - cube ) >= epsilon:
    print("Failed on the cube root of",cube)
else:
    print(guess,"is close to the cube root of ",cube)
plt.plot(g)
plt.xlabel("Guess")
plt.show()
