guess =0.0
cube = 27
increment =0.1
epsilon =0.1  #Error Tolerance
 

#finding the approximate value
for i in range(30):
    guess+=increment
    if abs(guess**3 - cube) < epsilon:
        break

#checking the approximate value value
if abs(guess**3 - cube ) >= epsilon:
    print("Failed on the cube root of",cube)
else: 
    print(guess,"is close to the cube root of ",cube)
