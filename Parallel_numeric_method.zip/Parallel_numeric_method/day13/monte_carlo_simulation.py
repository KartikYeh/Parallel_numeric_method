import numpy as np
sigma=1 
pt=5000
l=[]
total=0
x= np.random.normal(5,sigma,pt)
y= np.random.normal(10,sigma,pt)
z= np.random.normal(15,sigma,pt)

for i in range(0,len(x)):
    l.append(x[i]+y[i]+z[i])


for j in range(0,len(l)):
        if (l[j]>=34):
            total+=1
# print(total)

ans=(total*100)/pt
print("probaability is: ",ans,"%")
