from scipy import stats
import numpy as np

import matplotlib.pyplot as plt

N = 10000
a,b = (50,50)

x_min,x_max=(0,.55)

randx = np.random.uniform(x_min,x_max,N)

y=stats.beta.pdf(randx,a,b)

beta_at_55=stats.beta(a,b).cdf(.55)

Mcarlo_width = x_max-x_min

Mcarlo_react_area=Mcarlo_width*y.sum()
Mcarlo_react_area_avg=Mcarlo_react_area/N
print(f'Real value to find: {beta_at_55}') 
print(f'Integral value: {Mcarlo_react_area_avg}')