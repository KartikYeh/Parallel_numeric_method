import numpy as np
from scipy.integrate import quad
a=-2
b=5
ans=0
sum=0

def f(x):
    return x**3+(6*(x**2))-x+17
s= np.random.uniform(-2,5,20000)
res,error =quad(f,-2,5)
print("without function: ",abs(res))
for i in s:
    sum += abs((b-a)*(f(i)))
ans=abs(sum/len(s))
print("with fuction: ",ans)
    
