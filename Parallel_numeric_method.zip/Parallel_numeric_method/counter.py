guess =1.0
cube = 27
increment =0.1
epsilon =0.1  #

#finding the approximate value
for guess in range (30):
    if abs(guess**3 - cube) >= epsilon:
        guess=guess-1
    else:
        break

#checking the approximate value value
if abs(guess**3 - cube ) >= epsilon:
    print("Failed on the cube root of",cube)
else: 
    print(guess,"is close to the cube root of ",cube)