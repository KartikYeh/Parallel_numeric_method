# monte carlo simulation 3
import numpy as np
N=100000
x=np.random.uniform(-1,1,N)
y=np.random.uniform(-1,1,N)
n=0
for i in range(0,N):
    if x[i]**2+y[i]**2 <= 1:
        n+=1
pi=(n/N)*4
print("The value of pi is: ",round(pi,3))