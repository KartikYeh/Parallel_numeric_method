from math import sin
from math import cos

a = float(input("enter thevalue of a: "))
b = float(input("enter thevalue of a: "))
def f(x):
    z = sin(5*x)+cos(2*x)
    return z

for i in range(20):
    if (f(a)*f(b)<0):
        xi=(a+b)/2
        if (round(f(xi),3 )==0):
            print("root is",round(xi,3))
            break
        elif(f(a)*f(xi)<0):
            b=xi
        else:
            a=xi
    else:
        print("Root does not exit in this scope..")
        break