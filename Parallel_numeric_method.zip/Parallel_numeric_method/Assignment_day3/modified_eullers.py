import numpy as np

h=0.2
x=[]
for i in np.arange(0,2):
     xn=i*h
     x.append(xn)
print(x)
yo=1
for i in range(0,len(x)):
        yn=yo+(i+((x[i])**2))*h
print("y1 : ",yn)
y1=yn-h**2
print("f(x1,y1): ",round(y1,3))
# # modified eulers method
for j in range(0,2):
        ym=yo+(h/2)*(yn)+ y1#(y1-x[j]**2)
        ym=ym-x[j]**2
ym=1+(h/2)*(ym+1)
print("value by modified euler: ",ym)
