import numpy as np
import matplotlib.pyplot as plt
y=0
y1=3
m=6
x1=2

x=np.arange(0,10)
y=(m*(x-x1))+y1
plt.scatter(x1,y1)
plt.plot( x,y)
plt.xlabel('x values')
plt.ylabel('y values')
plt.title('Line Graph of y-3 = 6(x-2)')
plt.legend()
plt.show()
