from numpy.random import SeedSequence, default_rng
ss = SeedSequence(12345)

#spawn of 10 child seedsequences to pass to child processes
child_seeds = ss.spawn(10)
# print(child_seeds)
stream = [default_rng(s) for s in child_seeds] #check child seed values
# print(stream)
grandchildren = child_seeds[0].spawn(10)
# print(grandchildren)
grand_streams = [default_rng(s) for s in grandchildren]
# print(grand_streams)
print(grandchildren[5].pool)