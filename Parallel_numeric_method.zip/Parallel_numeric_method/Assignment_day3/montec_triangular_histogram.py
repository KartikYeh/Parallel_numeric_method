import numpy as np
import matplotlib.pyplot as plt
s= np.random.triangular(-3,2,8,100000)
plt.hist(s,bins=7,density=True,alpha=0.6,color='b')
plt.show()