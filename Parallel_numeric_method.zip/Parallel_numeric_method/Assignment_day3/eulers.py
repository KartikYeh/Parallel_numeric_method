import numpy as np

h=0.02
x=[]
for i in np.arange(1,7):
     xn=i*h
     x.append(xn)
print(x)
y=1
for i in range(0,6):
        yn=y+(((x[i])**3)+y)*h
        y=yn
        print(y)
        