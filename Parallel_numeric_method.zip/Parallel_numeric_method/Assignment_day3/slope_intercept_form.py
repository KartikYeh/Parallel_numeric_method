import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


m=2
b=3
y=0
x = np.linspace(-10, 10, 100)
y = m * x + b
plt.plot( x,y, label=f'y = {m}x + {b}')
plt.xlabel('x values')
plt.ylabel('y values')
plt.title('Line Graph of y = {m}x + {b}')
plt.legend()
plt.show()
