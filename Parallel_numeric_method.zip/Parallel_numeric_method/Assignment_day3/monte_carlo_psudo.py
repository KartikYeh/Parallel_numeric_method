import random 
from datetime import datetime
#passing the current time astime as the seed value
dt=datetime.now()

# random.seed(int(dt.strftime('%Y%m%d%H%M%S%f')))
random.seed(5)
for i in range(5):
    print(random.randint(0,10),end="\t")
print("\n")