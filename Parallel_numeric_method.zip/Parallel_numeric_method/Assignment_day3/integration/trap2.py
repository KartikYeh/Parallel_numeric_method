import numpy as np
from scipy.integrate import trapz

def IF(x):
    return 2 + 2*x + x**2 + np.sin(2*np.pi*x) + np.cos(2*np.pi*x/0.5)

n_values = [1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0]

for n in n_values:
    x = np.linspace(0, 1.5, int(n))
    y = IF(x)
    result = trapz(y, x)
    print(f"Numerical integration with n = {n} is: {result}")