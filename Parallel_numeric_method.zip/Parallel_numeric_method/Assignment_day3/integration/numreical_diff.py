import numpy as np
import matplotlib.pyplot as plt
list3=[]
x= np.arange(-2,6,0.1)
m=-x**2+4*x+5
n=-2*x+4
for i in np.arange(-2,6,0.1):
    list3.append(-2)
plt.scatter(x,m,s=0.8)
plt.plot(x,n)
plt.plot(x,list3)
plt.xlabel('x values')
plt.ylabel('y values')
plt.title('Line Graph of x2+4x+5')
plt.legend()
plt.show()